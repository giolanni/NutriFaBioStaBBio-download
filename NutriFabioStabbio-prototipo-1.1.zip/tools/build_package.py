#!/usr/bin/env python3
import argparse, json, pathlib, zipfile

def main():
    p=argparse.ArgumentParser(description="Crea un pacchetto ricette per Nutri Fabio Stabbio")
    p.add_argument("recipes_json"); p.add_argument("output_zip"); p.add_argument("--images", default=None)
    a=p.parse_args(); src=pathlib.Path(a.recipes_json)
    data=json.loads(src.read_text(encoding="utf-8")); recipes=data if isinstance(data,list) else data.get("recipes",[])
    ids=set()
    for r in recipes:
        if not r.get("id") or not r.get("title"): raise SystemExit("Ogni ricetta richiede id e title")
        if r["id"] in ids: raise SystemExit(f"ID duplicato: {r['id']}")
        ids.add(r["id"])
    manifest={"format":"nutri-fabio-pack","version":1,"recipes":len(recipes)}
    with zipfile.ZipFile(a.output_zip,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json",json.dumps(manifest,ensure_ascii=False,indent=2))
        z.writestr("recipes.json",json.dumps(recipes,ensure_ascii=False,indent=2))
        if a.images:
            root=pathlib.Path(a.images)
            for f in root.iterdir():
                if f.is_file() and f.suffix.lower() in {'.jpg','.jpeg','.png','.webp'}: z.write(f,"images/"+f.name)
    print(f"Creato {a.output_zip}: {len(recipes)} ricette")
if __name__=="__main__": main()
