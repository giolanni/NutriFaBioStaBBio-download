# Nutri Fabio Stabbio — prototipo 1.1

App Android offline per archiviare e cercare ricette. Include ricerca per nome/ingrediente, filtri, scheda ricetta, macro, importazione incrementale ZIP/JSON e ricettari personali.

Ogni profilo può creare, modificare ed eliminare le proprie ricette, scegliendo tra visibilità **privata** e **pubblica**. Le ricette pubbliche compaiono nella sezione **Community**; nel prototipo la community è simulata localmente. La condivisione effettiva tra dispositivi richiederà nella fase online un servizio di autenticazione e sincronizzazione.

## Apertura

Aprire questa cartella con Android Studio, attendere la sincronizzazione Gradle e avviare su Android 8 o successivo. Il progetto non richiede il permesso Internet.

## Pacchetti

Il file ZIP deve contenere `recipes.json` e, facoltativamente, `images/`. Gli ID esistenti vengono aggiornati, quelli nuovi aggiunti.

```bash
python tools/build_package.py examples/recipes.json pacchetto_demo.zip --images examples/images
```

L'app accetta anche un `recipes.json` senza ZIP. Le immagini incorporate nel pacchetto sono limitate a 5 MB ciascuna.
